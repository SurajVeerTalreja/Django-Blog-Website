from django.urls import path
from . import views

urlpatterns = [ 
    path('', views.PostTempelateView.as_view(), name='home-page'),
    path('posts/', views.PostListView.as_view(), name='all-posts-page'),
    path('read_later/', views.ReadLaterView.as_view(), name='read-later'),
    path('posts/<slug:slug>', views.PostDetailView.as_view(), name='post-page'),

]